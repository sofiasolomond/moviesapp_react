import axios  from "axios";
import IMovies from "../models/IMovies";

const baseUrl = process.env.REACT_APP_API_BASE_URL;

type Props = {
    id:number,
    type:string

}
const getMovieDetails = ( {id, type} : Props) => {
    return axios.get<IMovies>(`${baseUrl}/${type}/${id}`)
    .then(Response=> Response.data)
}

export {
    getMovieDetails
}