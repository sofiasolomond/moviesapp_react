import axios  from "axios";
import IMovies from "../models/IMovies";

const baseUrl = process.env.REACT_APP_API_BASE_URL;
const getTopRateIndianMovies = async() => {
    return axios.get<IMovies []>(`${baseUrl}/top-rated-india`)
    .then(Response=> Response.data)
}

export {
    getTopRateIndianMovies
}