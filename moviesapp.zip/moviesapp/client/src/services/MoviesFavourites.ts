import axios  from "axios";
import IMovies from "../models/IMovies";

const baseUrl = process.env.REACT_APP_API_BASE_URL;
const getFavouriteMovies = async() => {
    return axios.get<IMovies []>(`${baseUrl}/favourit`)
    .then(Response=> Response.data)
}

const setFavouritesMovie = async (movie: IMovies) => {
    // const response = await axios.post<IMovies>(`${baseUrl}/favourites`,
    // movie, {
    //     headers: {
    //         'Contet-Type': 'application/json'
    //     }
    // });
    // return response.data

    return  axios.post<IMovies>(`${baseUrl}/favourit`,
    movie, {
        headers: {
            'Contet-Type': 'application/json'
        }
    }).then(Response => Response.data)
    .catch(Response => Response.error);
    
};


const deleteFavouriteMovies = async (id: number) => {
    // const response = await axios.post<IMovies>(`${baseUrl}/favourites`,
    // movie, {
    //     headers: {
    //         'Contet-Type': 'application/json'
    //     }
    // });
    // return response.data

    return  axios.delete<number>(`${baseUrl}/favourit/${id}`,
  ).then(Response => Response.data)
    .catch(Response => Response.error);
    
};
export {
    getFavouriteMovies,
    setFavouritesMovie,
    deleteFavouriteMovies
}