import axios  from "axios";
import IMovies from "../models/IMovies";

const baseUrl = process.env.REACT_APP_API_BASE_URL;
const getTopRatedMovies = async() => {
 
    return axios.get<IMovies []>(`${baseUrl}/top-rated-movies`)
    .then(Response=> Response.data)

}

export {
    getTopRatedMovies
}