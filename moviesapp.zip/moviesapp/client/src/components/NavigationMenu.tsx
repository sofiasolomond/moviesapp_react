import { Container, Form, FormControl, Button } from "react-bootstrap";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { solid } from '@fortawesome/fontawesome-svg-core/import.macro'
import Navbar from 'react-bootstrap/Navbar'
import Nav from 'react-bootstrap/Nav'
import SearchMovies from '../components/MovieSearch'
import { ChangeEvent, useState } from "react";
import { useEffect, useRef } from 'react';


const NavigationMenu = () => {
  const [search, setSearch] = useState<boolean>(false)
  const [searchString, setSearchString] = useState<string>("")

  const handleChange = (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    console.log(event.target.value)
    console.log(search)
    setSearchString(event.target.value);
    setSearch(true)

  };

  useEffect(() => {
    setSearch(false)
  });

  const handleSubmit = () => {
    setSearch(true)
  };

  return (

    <>
      <Navbar variant="dark" bg="primary" expand="lg" sticky="top">
        <Container fluid>
          <Navbar.Brand href="/">
            <FontAwesomeIcon icon={solid('clapperboard')} /> &nbsp; Movies on the Tip</Navbar.Brand>
          <Navbar.Toggle aria-controls="navbarScroll" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav
              className="me-auto"
              style={{ maxHeight: '100px' }}
              navbarScroll
            >
              <Nav.Link href="/comingsoon">Coming Soon</Nav.Link>
              <Nav.Link href="/moviesintheater"> Movies in theaters</Nav.Link>
              <Nav.Link href="/topratedindia">Top rated Indian</Nav.Link>
              <Nav.Link href="/topratedmovies">Top rated</Nav.Link>
              <Nav.Link href="/favourites">Favourite</Nav.Link>
            </Nav>
            <Form className="d-flex">
              <FormControl
                type="search"
                placeholder="Search"
                className="me-2"
                aria-label="Search"
                onChange={(event) => handleChange(event)}
              />
              <Button variant="success" onClick={(event) => { handleSubmit() }}>Search</Button>
            </Form>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      {
        search &&  <SearchMovies searchString={searchString}  />
      }
    </>
  );
}


export default NavigationMenu