import IMovies from "../models/IMovies"
import { useState } from 'react'
import { Button, Card, Nav, Container, Row, Col } from 'react-bootstrap'
import { Link } from "react-router-dom";
import { useLocation } from 'react-router-dom'
type Props = {
    movieDetails: IMovies
}
const divStyle = {
    display: "flex",
    FlexDirection: "row"
};



const DisplayMovie = () => {
    const [open, setOpen] = useState(false);
    let location = useLocation();
    // console.log(location)
    const movieDetails = location.state as IMovies
    console.log(movieDetails)
    return (
        <>
            <Nav.Link as={Link} to="/comingsoon">Back Home</Nav.Link>

            <Container>
                <Row>
                    <Col xs={1} md={6} lg={4}>
                        <Card style={{ display: 'inline' }} className="text-center my-4">
                            <Card.Img variant="top" src={movieDetails.posterurl} alt="Image Missing" />
                        </Card>

                    </Col>

                    <Col>
                        <div style={{ display: 'inline' }} className="text-center my-4">

                            <Card.Header as="h5">{movieDetails.title} ( {movieDetails.year})</Card.Header> </div>
                        <div className="text-left">
                            <Row>
                                <Col xs={1} md={2} lg={4}> IMDB Rating : </Col>
                                <Col>{movieDetails.imdbRating}</Col>
                            </Row>
                            <Row>
                                <Col xs={1} md={2} lg={4}> Content Rating : </Col>
                                <Col>{movieDetails.contentRating}</Col>
                            </Row>
                            <Row>
                                <Col xs={1} md={2} lg={4}> Average Rating : </Col>
                                <Col>{movieDetails.averageRating}</Col>
                            </Row>
                            <Row>
                                <Col xs={1} md={2} lg={4}> Duration : </Col>
                                <Col>{movieDetails.duration}</Col>
                            </Row>
                            <Row>
                                <Col xs={1} md={2} lg={4}> Genres : </Col>
                                <Col>{movieDetails.genres.join(", ")}</Col>
                            </Row>
                            <Row>
                                <Col xs={1} md={2} lg={4}> Actors : </Col>
                                <Col>{movieDetails.actors.join (", ")}</Col>
                            </Row>
                            <Row>
                                <Col xs={1} md={2} lg={4}> Release Date : </Col>
                                <Col>{movieDetails.releaseDate}</Col>
                            </Row>
                            <Row>
                                <Col xs={1} md={2} lg={4}> Storyline : </Col>
                                <Col>{movieDetails.storyline}</Col>
                            </Row>
                        </div>

                    </Col>
                </Row>

            </Container>
        </>
    )
}

export default DisplayMovie