import { useEffect, useState } from "react"
import IMovies from '../models/IMovies'
import { getUpcomingMovies } from '../services/MoviesUpcoming'
import DisplayMovies from '../components/MoviesList'

const ComingSoon = () => {
    const [moviesList, setMoviesList] = useState<IMovies[]>([])
    useEffect(
        () => {
            const fetchList = async () => {
                getUpcomingMovies()
                    .then(data => setMoviesList(data))
                    .catch(error=> alert(error.message))                }
            fetchList()
        }, []
    )
    return (
      <DisplayMovies moviesList={moviesList}/>
    );
}

export default ComingSoon