import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { useState, useEffect, MouseEventHandler } from "react"
import { Route, Router, NavLink, Link } from 'react-router-dom'
import { Toast, ToastContainer, Figure } from 'react-bootstrap'

import { Button, Card, Row, Col, Collapse } from 'react-bootstrap'
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro'
import IMovies from "../models/IMovies";
import DisplayMovie from "../components/DisplayMovieCard"
import AddToFavourite from './AddToFavourite'
import { getFavouriteMovies, setFavouritesMovie } from '../services/MoviesFavourites'
import AlertMessage from '../components/common/AlertToaster'
type Props = {
  moviesList: IMovies[]
}


const DisplayMovies = ({ moviesList }: Props) => {
  const [show, setShow] = useState(false);
  const [movieToAdd, setMovie] = useState<IMovies>(moviesList[0])
  const addMovie = (movie: IMovies) => {
    console.log("SEt movie")
    setShow(true) 
    setMovie(movie)
  }

  return (
    <>
      {
        <Row xs={2} md={4} className="g-4">
          {
            moviesList.map(
              (movies, idx) => (
                <Col key={movies.id}>
                  <Card style={{ width: '18rem' }} className="text-center my-4" border="info">
                    <Link to={`/displaymovie`} state={movies}>
                      <Card.Img style={{ height: '18rem' }} variant="top" src={movies.posterurl}  alt="Image Missing" />
                    </Link>
                    <Card.Body>
                      <Card.Title>{movies.title}</Card.Title>
                      <Button variant="outline-primary" size="sm" onClick={() => {
console.log("Buttno clicked")
                      addMovie(movies)}}>  Add to Favourites
                      <div></div>
                        <FontAwesomeIcon icon={solid('heart')} />
                      </Button>
                    </Card.Body>
                  </Card>
                  {
                    show && movies.title === movieToAdd.title && <AddToFavourite movieDetails={movies} />
                    // show &&  <AddToFavourite movieDetails={movieToAdd} />

                  }
                </Col>
              ))
          }
        </Row>
      }
      </>
  )
}

export default DisplayMovies