import { type } from '@testing-library/user-event/dist/type';
import React, { useState, useEffect } from 'react';
import IMovies from "../models/IMovies";
import DisplayMovies from '../components/MoviesList'
import { getFavouriteMovies } from '../services/MoviesFavourites'
import { getUpcomingMovies } from '../services/MoviesUpcoming'

import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';

import MovieDetails from './MovieDetails';

type Props = {
    searchString: string
}


function SearchMovies({ searchString }: Props) {
    const [searchFromMovieList, setMoviesList] = useState<IMovies[]>([])
    const [movieToSearch, setMovieToSearch] = useState("");
    const [filteredMovies, setfilteredMovies] = useState<IMovies[]>([])

    useEffect(
        () => {
            setMovieToSearch(searchString);

            const fetchList = async () => {
                const currentPathName = window.location.href
                const baseUrl = process.env.REACT_APP_API_BASE_URL;
                let url = ""
                if (currentPathName.includes("comingsoon")) {
                    console.log("Setting the URL")
                    url = "comingsoon"
                }
                switch (url) {
                    case "comingsoon":
                        console.log("into the coming soon ")
                        await getUpcomingMovies()
                            .then((data) => {
                                console.log("Data of coming soon")
                                console.log(data)
                                setMoviesList(data)
                                const filteredMovies1 = data.filter(
                                    (movie) => {
                                        console.log("Into the filter function")
                                        console.log("movieToSearch" + searchString)
                                        return (
                                            movie.title
                                                .toLowerCase()
                                                .includes(searchString.toLowerCase()))
                                    })
                                console.log("FIletered")
                                console.log(filteredMovies1)
                                setfilteredMovies([...filteredMovies1])

                            })
                            .catch(error => console.log("error"));
                        break;
                    case (`${baseUrl}/moviesintheater`): console.log('Go to Eest Direction');
                        break;
                    case (`${baseUrl}/topratedindia`): console.log('Go to Soutch Direction');
                        break;
                    case (`${baseUrl}/favourites`): console.log('Go to West Direction')
                        break;
                    case (`${baseUrl}/topratedmovies`): console.log('Go to West Direction')
                        break;
                    default:
                        console.log('invalid direction');

                }
            }
            fetchList()


        }, []
    )


    console.log("FIletered after update")
    console.log(filteredMovies)

    return (
        <>
          
            <DisplayMovies moviesList={filteredMovies} />

        </>
    );
}

export default SearchMovies;