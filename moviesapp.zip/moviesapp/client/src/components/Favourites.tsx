import { useEffect, useState } from "react"
import IMovies from '../models/IMovies'
import { getFavouriteMovies } from '../services/MoviesFavourites'
import DisplayMovies from '../components/MoviesList'

const Favourites = () => {
    const [moviesList, setMoviesList] = useState<IMovies[]>([])
    useEffect(
        () => {
            const fetchList = async () => {
                getFavouriteMovies()
                    .then(data => setMoviesList(data))
                    .catch(error=> alert(error.message))                }
            fetchList()
        }, []
    )
    return (
      <DisplayMovies moviesList={moviesList}/>
    );
}

export default Favourites