import { useState, useEffect } from "react"
import IMovies from "../models/IMovies"
import { getFavouriteMovies, setFavouritesMovie } from '../services/MoviesFavourites'
import { Alert, Card, Toast, ToastContainer } from 'react-bootstrap'
import AlertMessage from "./common/AlertToaster"
import { title } from "process"
import LoadingIndicator from "./common/LoadingIndicator"
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome"
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro'

type Props = {
  movieDetails: IMovies,
}
const AddToFavourite = ({ movieDetails }: Props) => {
  const [moviesList, setMoviesList] = useState<IMovies[]>([]);
  const [successAlert, setSuccessAlertsVisible] = useState(false);
  const [errorAlert, setErrorAlertsVisible] = useState(false);
  const [show, setShow] = useState(false);

  let id: number
 
  useEffect(
    () => {
      const toFavourite = async (movie: IMovies) => {
        try {
          console.log("into the try block")
          await getFavouriteMovies()
            .then(data => {
              id = data.length
              data.map(
                (movies, idx) => (
                  movies.title === movie.title && setErrorAlertsVisible(true)

                ))
              movie.id = id + 1
            
            })
            .catch(error => alert(error.message))
    
        }
        catch (error) {
          console.log("Error in catch ")
          setErrorAlertsVisible(true)
    
        }
    
      }
      toFavourite(movieDetails)
      if (errorAlert == false) {
        (

          setFavouritesMovie(movieDetails)
            .then(data => {
              console.log("DATA is " + data)
              setSuccessAlertsVisible(true)
            })
            .catch(error => {
              console.log("Error alert")
              alert(error.message)
            }))
      }
      // else {
      //   setErrorAlertsVisible(false)
      // }
      setShow(true)

    }, []
  )

  return (
    <>

      <div>
        {
          successAlert && (
            <ToastContainer className="p-3" position="top-end" >
              <Toast bg="info" onClose={() => setShow(false)} show={show} delay={3000} autohide>
                <Toast.Header closeButton={false}>
                  <img
                    src="holder.js/20x20?text=%20"
                    className="rounded me-2"
                    alt=""
                  />

                  <strong className="me-auto">Favourites Added</strong>
                  <small>11 mins ago</small>
                </Toast.Header>
                <Toast.Body>               <p></p>
{movieDetails.title} added into favourites list
<p></p>
                </Toast.Body>
              </Toast>
            </ToastContainer>

          )
        }
        {

          errorAlert && (
            <ToastContainer className="p-3" position="top-end" >
              <Toast bg="info" onClose={() => setShow(false)} show={show} delay={3000} autohide>
                <Toast.Header closeButton={false}>
                  <img
                    src="holder.js/20x20?text=%20"
                    className="rounded me-2"
                    alt=""
                  />
                  <strong className="me-auto">Error Adding Favuorites</strong>
                </Toast.Header>
                <Toast.Body> {movieDetails.title} already available in favourites list
                </Toast.Body>
              </Toast>
            </ToastContainer>

          )
        }
      </div>
    </>
  )

}

export default AddToFavourite