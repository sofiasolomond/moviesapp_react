import { useEffect, useState } from "react"
import IMovies from '../models/IMovies'
import DisplayMovies from '../components/MoviesList'
import { getMoviesInTheaters } from '../services/MoviesInTheater'

const MoviesInTheatre = () => {
    const [moviesList, setMoviesList] = useState<IMovies[]>([])
    useEffect(
        () => {
            const fetchList = async () => {
                getMoviesInTheaters()
                    .then(data => setMoviesList(data))
                    .catch(error=> alert(error.message))                }

            fetchList()
        }, []
    )
    return (
      <DisplayMovies moviesList={moviesList}/>
    );
}

export default MoviesInTheatre