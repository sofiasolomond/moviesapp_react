import { useEffect, useState } from "react"
import { getTopRateIndianMovies } from '../services/MoviesTopRatedIndia'
import DisplayMovies from '../components/MoviesList'
import IMovies from '../models/IMovies'

const TopRatedIndia = () => {
    const [moviesList, setMoviesList] = useState<IMovies[]>([])
    useEffect(
        () => {
            const fetchList = async () => {
                getTopRateIndianMovies()
                    .then(data => setMoviesList(data))
                    .catch(error=> alert(error.message))                }

            fetchList()
        }, []
    )
    return (
      <DisplayMovies moviesList={moviesList}/>
    );
}

export default TopRatedIndia