import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { useState } from "react"
import { Link } from 'react-router-dom'
import { getFavouriteMovies, setFavouritesMovie, deleteFavouriteMovies } from '../services/MoviesFavourites'

import { Button, Card, Row, Col } from 'react-bootstrap'
import { solid } from '@fortawesome/fontawesome-svg-core/import.macro'
import IMovies from "../models/IMovies";
import AddToFavourite from './AddToFavourite'
import DeleteFromFavourite from "./DeleteFromFavourite"
type Props = {
  moviesList: IMovies[]
}

const DisplayFavouriteMovies = () => {
  const [moviesList, setMoviesList] = useState<IMovies[]>([])
  const [show, setShow] = useState(false);
  const [movie, setMovie] = useState<IMovies>(moviesList[0])
  getFavouriteMovies()
    .then(data => setMoviesList(data)).catch(error => console.log("error"))
  
    const deleteMovie = (movie: IMovies) => {
    setShow(true)
    setMovie(movie)
  }

  return (
    <>
      <div>
        {
          <Row xs={2} md={4} className="g-4">
            {
              moviesList.map(
                (movies, idx) => (
                  <Col key={movies.id}>
                    <Card style={{ width: '18rem' }} className="text-center my-4" border="info">
                      <Link to={`/displaymovie`} state={movies}>
                        <Card.Img style={{ height: '18rem' }} variant="top" src={movies.posterurl} alt="Image Missing" />
                      </Link>
                      <Card.Body>
                        <Card.Title>{movies.title}</Card.Title>
                        <Button variant="outline-danger" size="sm" onClick={() => deleteMovie(movies)}>  Remove from Favourite
                          <div></div>

                          <FontAwesomeIcon icon={solid('heart')} />
                        </Button>
                      </Card.Body>
                    </Card>
                    {
                      show && movies.title === movie.title && <DeleteFromFavourite movieDetails={movies} />
                    }
                  </Col>
                ))
            }
          </Row>
        }
      </div >
    </>
  )
}

export default DisplayFavouriteMovies