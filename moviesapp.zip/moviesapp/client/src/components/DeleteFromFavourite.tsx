import { useState, useEffect } from "react"
import IMovies from "../models/IMovies"
import { getFavouriteMovies, setFavouritesMovie,deleteFavouriteMovies } from '../services/MoviesFavourites'
import { Alert, Card, Toast, ToastContainer } from 'react-bootstrap'
import AlertMessage from "./common/AlertToaster"
import { title } from "process"
import LoadingIndicator from "./common/LoadingIndicator"
import DisplayFavouriteMovies from "./MoviesFavorriteList"
type Props = {
  movieDetails: IMovies,
}
const DeleteFromFavourite = ({ movieDetails }: Props) => {
  const [moviesList, setMoviesList] = useState<IMovies[]>([])
  const [successAlert, setSuccessAlertsVisible] = useState(false);
  const [errorAlert, setErrorAlertsVisible] = useState(false);
  const [show, setShow] = useState(false);


  useEffect(
    () => {
      const deleteMovie = async (movie: IMovies) => {
        try {
          console.log("into the try block")
          await deleteFavouriteMovies(movie.id)
            .then(data => {
              // setMoviesList(data) 
              console.log(data)
              setShow(true)
            }).catch(error => alert(error))    
            }

        catch (error) {
          console.log("Error in catch ")
    
        }
    
      }
      console.log("USe Effect called")
      deleteMovie(movieDetails)
    }, []
  )

  return (
    <>

      <DisplayFavouriteMovies/>
      <div>

        {
          show && (
            <ToastContainer className="p-3" position="top-end" >
              <Toast onClose={() => setShow(false)} show={show} delay={5000} autohide>
                <Toast.Header closeButton={false}>
                  <img
                    src="holder.js/20x20?text=%20"
                    className="rounded me-2"
                    alt=""
                  />
                  <strong className="me-auto">Favourites Added</strong>
                  <small>11 mins ago</small>
                </Toast.Header>
                <Toast.Body><div></div>{movieDetails.title} added into favourites list
                </Toast.Body>
              </Toast>
            </ToastContainer>

          )
        }
       
      </div>

    </>
  )

}

export default DeleteFromFavourite