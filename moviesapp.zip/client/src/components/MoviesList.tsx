import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { useState, useEffect } from "react"
import { Route, NavLink, Link } from 'react-router-dom'

import { Button, Card, Row, Col, Collapse } from 'react-bootstrap'
import { solid, regular, brands } from '@fortawesome/fontawesome-svg-core/import.macro'
import IMovies from "../models/IMovies";
import DisplayMovie from "../components/DisplayMovieCard"
import addMovie  from './AddToFavourite'
import { getFavouriteMovies, setFavouritesMovie } from '../services/MoviesFavourites'

type Props = {
  moviesList: IMovies[]
}


// const addMovie = (movies : IMovies) => {
//   console.log("into use effect")

//    useAddMovie(movies)
  
// }


// const addMovie = (movie: IMovies) => {


//   const fetchList = async () => {
//     console.log("Add to fav fetch list")

//     setFavouritesMovie(movie)
//       .then(data => console.log(data))
//       .catch(error => alert(error.message))
//   }

//   useEffect(
//     () => {

//       fetchList()
//     }, []
//   )
// }
 
const DisplayMovies = ({ moviesList }: Props) => {
  const [open, setOpen] = useState(false);
  const [movie, setMovie] = useState<IMovies>()
  
  return (<div>
    {
      <Row xs={2} md={4} className="g-4">
        {
        // Array.from({ length: 4 }).map((_, idx) => (
          moviesList.map(
            (movies, idx) => (
              
              <Col key={movies.id}>

                <Card style={{ width: '18rem' }} className="text-center my-4" border="info">
                 
                 
                  <Link to={`/displaymovie`} state={movies}>
                  {/* <DisplayMovie movieDetails={movies}></DisplayMovie> */}

                  <Card.Img variant="top" src={movies.posterurl} alt="Image Missing" />
                </Link>
                  <Card.Body>
                    <Card.Title>{movies.title}</Card.Title>
                    <Button variant="outline-danger" size="sm" onClick={() => 
   addMovie(movies)}> Add to Favourites
                      <FontAwesomeIcon icon={solid('heart')} />
                    </Button>
                  </Card.Body>
                </Card>
              </Col>
            ))
            // )
            // )
            }
            </Row>}
  </div >
  )
}


export default DisplayMovies