import { useState, useEffect } from "react"
import IMovies from "../models/IMovies"
import { getFavouriteMovies,setFavouritesMovie } from '../services/MoviesFavourites'
import { Alert, Toast, ToastContainer } from 'react-bootstrap'
import AlertMessage from "./common/AlertToaster"
type Props = {
  movieDetails: IMovies
}


// const AddToFavourite = (movie: IMovies) => {
//   const [moviesList, setMoviesList] = useState<IMovies[]>([])
//   console.log("Add to fav before use")

//   const fetchList = async () => {
//     console.log("Add to fav before use")

//     getFavouriteMovies()
//       .then(data => setMoviesList(data))
//       .catch(error => alert(error.message))
//   }

//   useEffect(
//     () => {

//       fetchList()
//     }, []
//   )
//   const matchedItem = moviesList.find((i: any) => i.id === movie.id);
//   if (!matchedItem) {
//     setMoviesList([
//       ...moviesList,
//       { ...movie }
//     ])
//   }
//   else {
//     alert("item already added")
//   }

//   /*
//     const removeOneQtyOfItem = (item :any) => {
//         let matchedIdx = -1;
//         const newItems = items.map(
//             ( i:any, idx:any) => {
//                  if (i.id !== item.id) {
//                      return i
//                  }
//                  else {
//                      matchedIdx = idx
//                      return { ...i, qty: i.qty - 1 }
//                  }
//              }
//          );
//          if ( newItems[matchedIdx].qty === 0) {
//              newItems.splice(matchedIdx, 1)
//          }
//          setItems( newItems);
//     }
//   */
//   return (<></>);
// };


const addMovie = (movie: IMovies) => {

    setFavouritesMovie(movie)
      .then(data => <AlertMessage title={"dfdfd"} message={"dfdfd"}/>
      )
      .catch(error => <AlertMessage title={"dfdf"} message={"dfdfd"}/>
      )
  }

 
export default addMovie 