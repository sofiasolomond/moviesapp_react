import { useEffect, useState } from "react"
import { getTopRatedMovies } from '../services/MoviesTopRated'
import IMovies from '../models/IMovies'
import DisplayMovies from '../components/MoviesList'

const TopRatedMovies = () => {

    const [moviesList, setMoviesList] = useState<IMovies[]>([])
    useEffect(
        () => {
            const fetchList = async () => {
                getTopRatedMovies()
                    .then(data => setMoviesList(data))
                    .catch(error=> alert(error.message))                }

            fetchList()
        }, []
    )
    return (
      <DisplayMovies moviesList={moviesList}/>
    );
}

export default TopRatedMovies