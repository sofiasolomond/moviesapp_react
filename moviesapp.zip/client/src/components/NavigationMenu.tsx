import { Container, Form, FormControl, Button } from "react-bootstrap";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { solid } from '@fortawesome/fontawesome-svg-core/import.macro'
import Navbar from 'react-bootstrap/Navbar'
import Nav from 'react-bootstrap/Nav'

const NavigationMenu = () => {
  return (
    <Navbar variant="dark" bg="primary" expand="lg" sticky="top">
      <Container fluid>
        <Navbar.Brand href="/">
          <FontAwesomeIcon icon={solid('clapperboard')} /> &nbsp; Movies on the Tip</Navbar.Brand>
        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav
            className="me-auto"
            style={{ maxHeight: '100px' }}
            navbarScroll
          >
            <Nav.Link href="/comingsoon">Coming Soon</Nav.Link>
            <Nav.Link href="/moviesintheater"> Movies in theaters</Nav.Link>
            <Nav.Link href="/topratedindia">Top rated Indian</Nav.Link>
            <Nav.Link href="/favourites">Favourite</Nav.Link>

          </Nav>
          <Form className="d-flex">
            <FormControl
              type="search"
              placeholder="Search"
              className="me-2"
              aria-label="Search"
            />
            <Button variant="success">Search</Button>
          </Form>
        </Navbar.Collapse>
      </Container>
    </Navbar>
  );
}

export default NavigationMenu