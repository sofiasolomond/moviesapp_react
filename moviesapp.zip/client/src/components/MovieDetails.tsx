import { useState, useEffect } from "react";
import IMovies from "../models/IMovies";
import  DisplayMovie  from "../components/DisplayMovieCard"
import { getMovieDetails } from "../services/MovieDetails";
import LoadingIndicator from "../components/common/LoadingIndicator"
import { Toast, ToastContainer } from "react-bootstrap";

type Props = {
    id: number,
    type: string

}

const MovieDetails = ({ id, type }: Props) => {
    const [loading, setLoading] = useState<boolean>(true)
    const [movieDetails, setMovieDetails] = useState<IMovies>()
    const [error, setError] = useState<string>("")
    const [show, setShow] = useState<boolean>(false)

    useEffect(
        () => {
            const fetchMovieDetails = async () => {
                getMovieDetails({ id, type })
                    .then(data => setMovieDetails(data))
                    .catch(error => setError(error.response && error.response.data.message || error.message))
            }

            fetchMovieDetails()
        }, []
    )


    return (
        <>
            {
                loading && (
                    <LoadingIndicator size="large" message="Loading now" />
                )
            }
            {
                // movieDetails && ( <DisplayMovie movieDetails={movieDetails}/>)
            }
            {
                error && (
                    <ToastContainer position="top-end" className="p-3">
                        <Toast onClose={() => setShow(false)} show={show} delay={3000} autohide>
                            <Toast.Header>

                                <small className="text-muted">Loading Error</small>
                            </Toast.Header>
                            <Toast.Body>{error}</Toast.Body>
                        </Toast>

                    </ToastContainer>
                )
            }

        </>
    );
}

export default MovieDetails