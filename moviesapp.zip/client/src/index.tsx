import 'bootstrap/dist/css/bootstrap.min.css'
import '@fortawesome/fontawesome-svg-core'
import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Routes, Route, BrowserRouter } from 'react-router-dom';
import NavigationMenu from './components/NavigationMenu'
import ComingSoon from './components/ComingSoon'
import MoviesInTheatre from './components/MoviesInTheatre'
import TopRatedMovies from './components/TopRated'
import TopRatedIndia from './components/TopRateIndia';
import LoadingIndicator from './components/common/LoadingIndicator';
import MovieDetails from './components/MovieDetails';
import DisplayMovie from './components/DisplayMovieCard';
import Favourites from './components/Favourites'
import AlertMessage from './components/common/AlertToaster';
const root = ReactDOM.createRoot(
  document.getElementById('root') as HTMLElement
);

root.render(
  <React.StrictMode>
    <NavigationMenu />
    <BrowserRouter>
      <Routes>
        <Route path='/displaymovie' element={<DisplayMovie />}></Route>
        <Route path='/favourites' element={<Favourites />}></Route>
        <Route path='/moviesintheater' element={<MoviesInTheatre />}></Route>
        <Route path='/comingsoon' element={<ComingSoon />}></Route>
        <Route path='/topratedindia' element={<TopRatedIndia />}></Route>
        <Route path='/topratedmovies' element={<TopRatedMovies />}></Route>
      </Routes>
    </BrowserRouter>
  </React.StrictMode>
);
