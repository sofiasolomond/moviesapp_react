import axios  from "axios";
import IMovies from "../models/IMovies";

const baseUrl = process.env.REACT_APP_API_BASE_URL;
const getUpcomingMovies = async() => {    
    return axios.get<IMovies []>(`${baseUrl}/movies-coming`)
    .then(Response=> Response.data)
}

export {
    getUpcomingMovies
}